
import UIKit
import PlaygroundSupport

let drawController = DrawController()
// drawController.view.frame = CGRect(x: 0, y: 0, width: 1024, height: 768)
PlaygroundPage.current.liveView = drawController //.view
