
import UIKit
import PlaygroundSupport

PlaygroundPage.current.liveView = GenesisController()
