//#-hidden-code
import UIKit
//#-end-hidden-code

//: **Genesis**: how do you draw a Bézier curve?


//#-editable-code

//#-end-editable-code
//: [Next](@next)