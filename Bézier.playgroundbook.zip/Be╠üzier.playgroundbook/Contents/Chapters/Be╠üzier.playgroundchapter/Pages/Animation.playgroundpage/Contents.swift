//#-hidden-code
import UIKit
//#-end-hidden-code

//: **Timing Functions** the key ingredient to design great animations

/*:
 Ciao come va?
 */
//#-editable-code

//#-end-editable-code
