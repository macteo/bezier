//
//  UIBezierPath.swift
//  ToneCurveEditor
//
//  Created by Simon Gladman on 15/09/2014.
//  Copyright (c) 2014 Simon Gladman. All rights reserved.
//
// Based on Objective C code from: https://github.com/jnfisher/ios-curve-interpolation/blob/master/Curve%20Interpolation/UIBezierPath%2BInterpolation.m
// From this article: http://spin.atomicobject.com/2014/05/28/ios-interpolating-points/

import Foundation
import UIKit

public extension UIBezierPath
{
    public func interpolatePointsWithHermite(interpolationPoints : [CGPoint], alpha: CGFloat = 1.0/3.0, closed : Bool = false) -> [CGPoint]
    {
        var controlPoints = [CGPoint]()
        
        guard !interpolationPoints.isEmpty else { return controlPoints }
        
        self.move(to: interpolationPoints[0])
        
        var n = interpolationPoints.count - 1
        
        if closed {
            n = interpolationPoints.count
        }
        
        for index in 0..<n
        {
            var currentPoint = interpolationPoints[index]
            var nextIndex = (index + 1) % interpolationPoints.count
            var prevIndex = index == 0 ? interpolationPoints.count - 1 : index - 1
            var previousPoint = interpolationPoints[prevIndex]
            var nextPoint = interpolationPoints[nextIndex]
            let endPoint = nextPoint
            var mx : CGFloat
            var my : CGFloat
            
            if closed || index > 0
            {
                mx = (nextPoint.x - previousPoint.x) / 2.0
                my = (nextPoint.y - previousPoint.y) / 2.0
            }
            else
            {
                mx = (nextPoint.x - currentPoint.x) / 2.0
                my = (nextPoint.y - currentPoint.y) / 2.0
            }
            
            let controlPoint1 = CGPoint(x: currentPoint.x + mx * alpha, y: currentPoint.y + my * alpha)
            currentPoint = interpolationPoints[nextIndex]
            nextIndex = (nextIndex + 1) % interpolationPoints.count
            prevIndex = index
            previousPoint = interpolationPoints[prevIndex]
            nextPoint = interpolationPoints[nextIndex]
            
            if closed || index < n - 1
            {
                mx = (nextPoint.x - previousPoint.x) / 2.0
                my = (nextPoint.y - previousPoint.y) / 2.0
            }
            else
            {
                mx = (currentPoint.x - previousPoint.x) / 2.0
                my = (currentPoint.y - previousPoint.y) / 2.0
            }
            
            let controlPoint2 = CGPoint(x: currentPoint.x - mx * alpha, y: currentPoint.y - my * alpha)
            
            self.addCurve(to: endPoint, controlPoint1: controlPoint1, controlPoint2: controlPoint2)
            
            controlPoints.append(controlPoint1)
            controlPoints.append(controlPoint2)
        }
        
        if closed {
            self.close()
        }
        
        return controlPoints
    }
}
