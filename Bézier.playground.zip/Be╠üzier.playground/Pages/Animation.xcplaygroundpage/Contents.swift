//: **Timing Functions** the key ingredient to design great animations

//#-live-view
import UIKit
import PlaygroundSupport

PlaygroundPage.current.liveView = AnimationController()
//#-end-live-view

/*:
 Ciao come va?
 */

//#-editable-code

//#-end-editable-code
