//: **Genesis**: how do you draw a Bézier curve?

//#-live-view
import UIKit
import PlaygroundSupport

PlaygroundPage.current.liveView = GenesisController()
//#-end-live-view

//#-editable-code

//#-end-editable-code


//: [Next](@next)
